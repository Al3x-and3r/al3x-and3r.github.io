<?php
session_start();
include("connection.php");
include("functions.php");







if(isset($_GET['Play']))
         {
             $musicI = $_GET['Play'];
             $user_id = $_SESSION['Account_ID'];
       
            $query = "select * from account where Account_ID = '$user_id'";
            $result = mysqli_query($con, $query);
        
            
       
             $query =  "insert into playlist (Account_ID, music_id) values ('$user_id','$musicI')";
             $result = mysqli_query($con,$query);
             if($result)
             {
                 header("location:musicrated.php");
             }
             else
             {
                 echo ' Please Check Your Query ';
             }
        }
         else
         {
             header("location:musicrated.php");
         }
         ?>
        
        
        


















-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 12, 2022 at 02:47 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `musicwebsite`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `Account_ID` int(100) NOT NULL,
  `Account_Name` varchar(15) NOT NULL,
  `Account_Password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`Account_ID`, `Account_Name`, `Account_Password`) VALUES
(6, 'admin', 'admin'),
(14, 'xx', 'xx'),
(16, 'joe', 'hello'),
(23, 'gg', 'gg'),
(24, 'admin15', 'admin10'),
(32, 'gmXO', '5945'),
(855, '0', 'a'),
(856, 'hcvu', '0'),
(905, 'sdf', '0'),
(922, 'asd', 'asd'),
(923, 'bsd', 'bsd'),
(1752, 'a', 'a'),
(1753, 'g', 'g'),
(1754, 'h', 'h'),
(1756, 'j', 'j'),
(1757, 'fgfg', 'hh'),
(1759, 'jj', 'jj'),
(1760, 'fghgfh', 'hfgh'),
(1761, 'ggfhghf', 'hh'),
(1762, 'da', 'da'),
(1763, 'SdCt', '1446'),
(11968, 'fds', 'f'),
(11969, 'ddfgdfg', 'dfgdfg'),
(11971, 'dfgdfgdfg', 'dfgdfgdfg'),
(11972, 'dsfdsf', 'dsf'),
(11973, 'dfgdf', 'dfgdfg'),
(11974, 'dfgdfg', 'dfgdfg'),
(11975, 'jimmy', 'hello'),
(11976, 'PZfI', '6217'),
(20692, 'testtest', 'asdasd'),
(20693, 'testing460', 'testing');

--
-- Triggers `account`
--
DELIMITER $$
CREATE TRIGGER `after_account_delete` AFTER DELETE ON `account` FOR EACH ROW BEGIN
    INSERT INTO auditaccount
    SET Action_Preformed  = 'Deleted a subscriber',
    Account_Name       =  OLD.Account_Name;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_account_edit` AFTER UPDATE ON `account` FOR EACH ROW BEGIN
    INSERT INTO auditaccount
    SET Action_Preformed  = 'Updated a subscriber',
    Account_Name       =  OLD.Account_Name;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_account_insert` BEFORE INSERT ON `account` FOR EACH ROW BEGIN
    INSERT INTO auditaccount
    SET Action_Preformed  = 'Inserted a new subscriber',
    Account_Name       =  new.Account_Name;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin_account`
--

CREATE TABLE `admin_account` (
  `Account_ID` int(100) NOT NULL,
  `Account_Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_account`
--

INSERT INTO `admin_account` (`Account_ID`, `Account_Name`) VALUES
(6, 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `auditaccount`
--

CREATE TABLE `auditaccount` (
  `Account_Name` varchar(15) NOT NULL,
  `Action_Preformed` text NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auditaccount`
--

INSERT INTO `auditaccount` (`Account_Name`, `Action_Preformed`, `Time`) VALUES
('testtest', 'Inserted a new subscriber', '2022-12-08 15:26:05'),
('ad', 'Deleted a subscriber', '2022-12-08 15:30:16'),
('admin10', 'Updated a subscriber', '2022-12-08 15:30:26'),
('', '', '2022-12-08 15:33:58'),
('testing460', 'Inserted a new subscriber', '2022-12-08 18:59:10');

-- --------------------------------------------------------

--
-- Table structure for table `auditmusic`
--

CREATE TABLE `auditmusic` (
  `music_title` varchar(35) NOT NULL,
  `new_music_title` varchar(35) NOT NULL,
  `music_year` int(4) NOT NULL,
  `new_music_year` int(4) NOT NULL,
  `music_author` varchar(30) NOT NULL,
  `new_music_author` varchar(30) NOT NULL,
  `action_performed` text NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `auditmusic`
--

INSERT INTO `auditmusic` (`music_title`, `new_music_title`, `music_year`, `new_music_year`, `music_author`, `new_music_author`, `action_performed`, `time`) VALUES
('Party Rock Anthem', 'Party Rock Anthe', 0, 0, '', '', 'Updated music', '0000-00-00 00:00:00'),
('Brasil', 'Brasil', 0, 0, '', '', 'Updated music', '0000-00-00 00:00:00'),
('Baila Morena', '', 0, 0, '', '', 'Deleted music', '0000-00-00 00:00:00'),
('', '', 0, 0, '', '', '', '2022-12-11 23:09:06'),
('Its my life', '', 0, 0, '', '', 'Deleted music', '2022-12-11 23:11:14'),
('Brasil', 'Bra', 1990, 1990, '', '', 'Updated music', '2022-12-11 23:11:21'),
('a', '', 1999, 0, 'a', '', 'Inserted new music', '2022-12-11 23:17:32');

-- --------------------------------------------------------

--
-- Table structure for table `music`
--

CREATE TABLE `music` (
  `music_id` int(11) NOT NULL,
  `music_title` varchar(35) NOT NULL,
  `music_author` varchar(35) NOT NULL,
  `music_year` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `music`
--

INSERT INTO `music` (`music_id`, `music_title`, `music_author`, `music_year`) VALUES
(1, 'You are the one that I want', 'T. S. Eliot', 1963),
(3, 'We are youngn', 'Doris Lessing', 1914),
(5, 'Lean on', 'Jane Austen', 1976),
(8, 'Bra', 'William Faulkner', 1990),
(10, 'Physical', 'Barbara Cartland', 1950),
(14, 'Lean on', 'Danielle Steel', 1916),
(15, 'Party Rock Anthe', 'Barbara Cartland', 2016),
(16, 'Let Me Love You', 'Danielle Steel', 1906),
(17, 'Cest la vie', 'Kurt Vonnegut', 1964),
(18, 'No One', 'Ralph Waldo Emerson', 2015),
(20, 'Corazon', 'Bella Forrest', 1935),
(21, 'La gozadera', 'Franz Kafka', 1952),
(22, 'These boots are made for walking', 'Carlos Ruiz Zafon', 2011),
(23, 'Le Freak', 'Jane Austen', 1967),
(24, 'YMCA', 'Jane Austen', 1994),
(26, 'Strongest', 'John Steinbeck', 1915),
(28, 'We Belong Together', 'Henry James', 1927),
(29, 'How Deep Is Your Love', 'Bella Forrest', 1935),
(30, 'Alors on dance', 'Harper Lee', 1942),
(31, 'La gozadera', 'Doris Lessing', 1965),
(32, 'Andalouse', 'Harper Lee', 1907),
(33, 'Bailando', 'William Faulkner', 1956),
(34, 'Baila Morena', 'Paulo Coelo', 1990),
(35, 'Cheap thrills', 'Robert Frost', 1949),
(36, 'Party Rock Anthem', 'Bella Forrest', 1947),
(37, 'Livin la vida loca', 'Dr. Seuss', 1932),
(38, 'Un-Break My Heart', 'Carolyn Brown', 1926),
(40, 'Tonights The Night', 'Guillaume Musso', 1986),
(41, 'YMCA', 'Ernest Hemingway', 1985),
(42, 'Tonights The Night', 'Jules Verne', 2016),
(43, 'Beat it', 'Herman Melville', 1948),
(44, 'Mercy ', 'Oscar Wilde', 1907),
(45, 'Cheri cheri lady', 'Bella Forrest', 1939),
(46, 'How Deep Is Your Love', 'J. R. R. Tolkien', 1993),
(47, 'You Light Up My Life', 'Jin Yong', 2021),
(48, '(Everything I Do) I Do It For You', 'Margaret Atwood', 2018),
(49, 'Highway to hell', 'Edith Wharton', 1940),
(50, 'Rolling In The Deep', 'Doris Lessing', 1904),
(51, 'Cheri cheri lady', 'Emily Dickinson', 1927),
(52, 'Cheri cheri lady', 'F. Scott Fitzgerald', 2001),
(53, 'Baila Morena', 'T. S. Eliot', 1901),
(54, 'Endless Loves', 'Stephen King', 1962),
(55, 'Hero', 'William Faulkner', 1958),
(56, 'Tonights The Night', 'J. K. Rowling', 1928),
(57, 'Blurred Lines', 'C.S. Lewis', 2004),
(58, 'I wanna dance with somebody', 'Ernest Hemingway', 1985),
(59, 'Bailando', 'G.R.R. Martin', 1926),
(60, 'Truly Madly Deeply', 'Jin Yong', 1935),
(61, 'YMCA', 'Mary Shelley', 2012),
(62, 'Yeah!', 'Kurt Vonnegut', 1977),
(63, 'Every Breath You Take', 'Barbara Cartland', 1940),
(64, 'Listen to your heart', 'Guillaume Musso', 1947),
(65, 'Cheri cheri lady', 'Ralph Waldo Emerson', 1973),
(66, 'I Just Want To Be Your Everything', 'Barbara Cartland', 1914),
(67, 'Listen to your heart', 'Jules Verne', 1913),
(68, 'Wake me up before you gogo', 'F. Scott Fitzgerald', 1964),
(69, 'Physical', 'Paulo Coelo', 1914),
(70, 'Lemon', 'William Faulkner', 1984),
(71, 'YMCA', 'Doris Lessing', 1921),
(72, 'Smooth', 'Rachel Hollis', 1973),
(73, 'Mack The Knife', 'Tennessee Williams', 1945),
(74, 'Every Breath You Take', 'Ralph Waldo Emerson', 1970),
(75, '(Everything I Do) I Do It For You', 'Ray Bradbury', 2016),
(76, 'Livin la vida loca', 'Alexandre Dumas', 1901),
(77, 'Endless Summer', 'Herman Melville', 1999),
(78, 'Wake me up before you gogo', 'Herman Melville', 1930),
(79, 'Physical', 'Stephen King', 1960),
(80, 'Eye Of The Tiger', 'Walt Whitman', 1955),
(81, 'Lemon', 'T. S. Eliot', 2005),
(82, 'Despacito', 'Jules Verne', 1962),
(83, 'Sway', 'Danielle Steel', 1967),
(84, 'Hero', 'Robert Frost', 1933),
(85, 'La gozadera', 'Henry James', 1961),
(86, 'I wanna dance with somebody', 'Paulo Coelo', 1902),
(88, 'Endless Summer', 'F. Scott Fitzgerald', 1998),
(89, 'How Deep Is Your Love', 'Stephen King', 1911),
(90, 'Party Rock Anthem', 'Leo Tolstoy', 1936),
(91, 'Endless Summer', 'Paulo Coelo', 1954),
(92, 'Beggin', 'Doris Lessing', 1907),
(93, 'Bailando', 'Edgar Allan Poe', 1964),
(94, 'Hey Jude', 'Agatha Christie', 1992),
(95, 'Livin la vida loca', 'John Steinbeck', 1942),
(96, 'I wanna dance with somebody', 'Ralph Waldo Emerson', 1969),
(97, 'La gozadera', 'Tennessee Williams', 1940),
(98, 'I Just Want To Be Your Everything', 'Rachel Hollis', 1957),
(99, 'Uptown Funk!', 'F. Scott Fitzgerald', 2008),
(100, 'The Twist', 'Bella Forrest', 1942),
(102, 'a', 'a', 1999);

--
-- Triggers `music`
--
DELIMITER $$
CREATE TRIGGER `after_music_delete` AFTER DELETE ON `music` FOR EACH ROW BEGIN
    INSERT INTO auditmusic
    SET action_performed  = 'Deleted music',
   music_title      =  OLD.music_title;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `after_music_edit` AFTER UPDATE ON `music` FOR EACH ROW BEGIN
    INSERT INTO auditmusic
    SET action_performed  = 'Updated music',
    new_music_title	  =  NEW.music_title ,
    music_title       =  OLD.music_title,
    new_music_year 	  = NEW.music_year ,
    music_year 		  = OLD.music_year,
    new_music_author      =  NEW.music_author,
    music_author          = OLD.music_author;	
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `before_music_insert` BEFORE INSERT ON `music` FOR EACH ROW BEGIN
    INSERT INTO auditmusic
    SET action_performed  = 'Inserted new music',
    music_title       =  new.music_title,
    music_author 	  = new.music_author,
    music_year        = new.music_year;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `playlist`
--

CREATE TABLE `playlist` (
  `Account_ID` int(11) NOT NULL,
  `music_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `playlist`
--

INSERT INTO `playlist` (`Account_ID`, `music_id`) VALUES
(922, 1),
(6, 38),
(6, 8),
(6, 14),
(6, 18),
(6, 20),
(6, 21),
(20693, 14);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(40) NOT NULL,
  `stock` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `stock`) VALUES
(1, 'SubscriptionKeys', 88);

-- --------------------------------------------------------

--
-- Table structure for table `subscribed_account`
--

CREATE TABLE `subscribed_account` (
  `Account_ID` int(100) NOT NULL,
  `Account_Name` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `subscribed_account`
--

INSERT INTO `subscribed_account` (`Account_ID`, `Account_Name`) VALUES
(6, 'admin'),
(11975, 'jimmy'),
(16, 'joe'),
(16, 'joe'),
(16, 'joe'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(20693, 'testing460'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin'),
(6, 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`Account_ID`),
  ADD UNIQUE KEY `Account_Name` (`Account_Name`);

--
-- Indexes for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD KEY `Account_ID` (`Account_ID`,`Account_Name`),
  ADD KEY `Account_Name` (`Account_Name`);

--
-- Indexes for table `music`
--
ALTER TABLE `music`
  ADD PRIMARY KEY (`music_id`),
  ADD KEY `music_title` (`music_title`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `playlist`
--
ALTER TABLE `playlist`
  ADD KEY `music_id` (`music_id`),
  ADD KEY `Account_ID` (`Account_ID`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `subscribed_account`
--
ALTER TABLE `subscribed_account`
  ADD KEY `Account_Name` (`Account_Name`),
  ADD KEY `Account_ID` (`Account_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `Account_ID` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20694;

--
-- AUTO_INCREMENT for table `music`
--
ALTER TABLE `music`
  MODIFY `music_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=103;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_account`
--
ALTER TABLE `admin_account`
  ADD CONSTRAINT `admin_account_ibfk_1` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`),
  ADD CONSTRAINT `admin_account_ibfk_2` FOREIGN KEY (`Account_Name`) REFERENCES `account` (`Account_Name`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `products` (`product_id`);

--
-- Constraints for table `playlist`
--
ALTER TABLE `playlist`
  ADD CONSTRAINT `playlist_ibfk_1` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`),
  ADD CONSTRAINT `playlist_ibfk_2` FOREIGN KEY (`music_id`) REFERENCES `music` (`music_id`);

--
-- Constraints for table `subscribed_account`
--
ALTER TABLE `subscribed_account`
  ADD CONSTRAINT `subscribed_account_ibfk_1` FOREIGN KEY (`Account_ID`) REFERENCES `account` (`Account_ID`),
  ADD CONSTRAINT `subscribed_account_ibfk_2` FOREIGN KEY (`Account_Name`) REFERENCES `account` (`Account_Name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php

	if(ISSET($_POST['search'])){
		$keyword = $_POST['keyword'];
?>
	<?php
		require 'connection.php';
		$query = mysqli_query($con, "SELECT * FROM `musicwebsite` WHERE `music_title` LIKE '%$FULLTEXT%' ORDER BY `music_title`") or die(mysqli_error());
		while($fetch = mysqli_fetch_array($query)){
        header('location:musicrated.php');
	?>
	<div style="word-wrap:break-word;">
		<a href="musicrated.php?id=<?php echo $fetch['id']?>"><h4><?php echo $fetch['music_title']?></h4></a>
		<p><?php echo substr($fetch['content'], 0, 100)?>...</p>
        
	</div>
	<hr style="border-bottom:1px solid #ccc;"/>
	<?php
		}
	?>
</div>
<?php
	}
?>

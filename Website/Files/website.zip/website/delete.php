<?php
require_once("connection.php");
if(isset($_GET['Del']))
         {
             $musicI = $_GET['Del'];
             $query = " delete from music where music_id = '".$musicI."'";
             $result = mysqli_query($con,$query);
             if($result)
             {
                 header("location:musicrated.php");
             }
             else
             {
                 echo ' Please Check Your Query ';
             }
        }
         else
         {
             header("location:musicrated.php");
         }
         ?>
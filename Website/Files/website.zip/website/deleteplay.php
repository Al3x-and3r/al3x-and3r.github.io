<?php
require_once("connection.php");
if(isset($_GET['Del']))
         {
             $musicI = $_GET['Del'];
             $query = " delete from playlist where music_id = '".$musicI."'";
             $result = mysqli_query($con,$query);
             if($result)
             {
                 header("location:account.php");
             }
             else
             {
                 echo ' Please Check Your Query ';
             }
        }
         else
         {
             header("location:account.php");
         }
         ?>
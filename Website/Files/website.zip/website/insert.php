<?php

    require_once("connection.php");

    if(isset($_POST['submit']))
    {
        if(empty($_POST['title']) || empty($_POST['author']) || empty($_POST['year']))
        {
            echo ' Please Fill in the Blanks ';
        }
        else
        {
            $musicT = $_POST['title'];
            $musicA = $_POST['author'];
            $musicY = $_POST['year'];

            $query = " insert into music (music_title, music_author,music_year) values('$musicT','$musicA','$musicY')";
            $result = mysqli_query($con,$query);

            if($result)
            {
                header("location:musicrated.php");
            }
            else
            {
                echo '  Please Check Your Query ';
            }
        }
    }
    else
    {
        header("location:index.php");
    }



?>
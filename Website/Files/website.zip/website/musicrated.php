<?php
      session_start();
    include("connection.php");
	include("functions.php");
  $query = " select * from music ";
  $result = mysqli_query($con,$query);
 

    ?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content=" " />
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
           <!-- Responsive navbar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
            <a class="navbar-brand" href="#">Music Rated</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Options</a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="signup.php">Sign up</a></li>
                                <li><a class="dropdown-item" href="account.php">Account</a></li>
                                <li><a class="dropdown-item" href="musicrated.php">Music</a></li>
                                <li><a class="dropdown-item" href="checkout.php">Subscribe</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="signout.php">Sign Out</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
        <div class="container">
            <div class="row">
                <div class="col m-auto">
                    <div class="card__mt-5">
                 
               
                    <table class="table table-bordered">
                   
                            <tr>
                                <td>  Music ID </td>
                                <td>  Music Title   </td>
                                <td>  Music Author   </td>
                                <td>  Music Year   </td>
                                <td>  Edit   </td>
                                <td>  Delete  </td>
                                <td>  Add to Playlist   </td>
                            </tr>

                            <?php 
                           
          
                       
                       
                                    while($row=mysqli_fetch_assoc($result))
                                    {
                                        $musicI = $row['music_id'];
                                        $musicT = $row['music_title'];
                                        $musicA = $row['music_author'];
                                        $musicY = $row['music_year'];
                            ?>
                                    <tr>
                                        <td><?php echo $musicI ?></td>
                                        <td><?php echo $musicT ?></td>
                                        <td><?php echo $musicA ?></td>
                                        <td><?php echo $musicY ?></td>
                                        <td><a href="edit.php?GetID=<?php echo $musicI ?>">Edit</a></td>
                                        <td><a href="delete.php?Del=<?php echo $musicI ?>">Delete</a></td>
                                        <td><a href="playlist.php?Play=<?php echo $musicI?>">Add to Playlist</a></td>
                                    </tr>        
                                    </tr>        
                            <?php 
                                    }  
                            ?>                                                                    
                                   

                     </table>
                     <form method="post">
<label>Search</label>
<input type="text" name="search">
<input type="submit" name="submit">

<?php

$con = new PDO("mysql:host=localhost;dbname=musicwebsite",'root','');
$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt = $con->prepare("INSERT INTO account (Account_ID, Account_Name, Account_Password)
  VALUES (:firstname, :lastname, :email)");
  $stmt->bindParam(':firstname', $firstname);
  $stmt->bindParam(':lastname', $lastname);
  $stmt->bindParam(':email', $email);


	


if (isset($_POST["submit"])) {
	$str = $_POST["search"];
	$sth = $con->prepare("SELECT * FROM `music` WHERE music_title = '$str'");


	$sth->setFetchMode(PDO:: FETCH_OBJ);
	$sth -> execute();
	
    if($row = $sth->fetch())
	{
		?>
		<br><br><br>
		<table>
			<tr>
				<th> Song Name </th>
				<th>     Artist </th>
			</tr>
			<tr>
				<td><?php echo $row->music_title; ?></td>
				<td><?php echo $row->music_author;?></td>
			</tr>

		</table>
<?php 
	}
		
		
		else{
			echo "Name Does not exist";
		}


}

?>


<div class="card-title">
                            <h3> Enter Music Here</h3>
                        </div>
                        <div class="card-body">

                            <form action="insert.php" method="post">
                                <input type="text" class="form-control mb-2" placeholder=" Music Title " name="title">
                                <input type="text" class="form-control mb-2" placeholder=" Music Author " name="author">
                                <input type="text" class="form-control mb-2" placeholder=" Music Year " name="year">
                                <button class="btn btn-primary" name="submit">Submit</button>
                            </form>
                   
	
</form>

</body>
</html>



                    </div>
                </div>
            </div>
        </div>

        

                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
     </div>
   </div>
      <!-- Bootstrap core JS-->
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
      <!-- Core theme JS-->
      <script src="js/scripts.js"></script>
  </section>
</body>
</html>


<?php



function check_login($con)
{

	if(isset($_SESSION['Account_ID']))
	{

		$user_ID = $_SESSION['Account_ID'];
		$query = "select * from account where Account_ID = '$user_ID' limit 1";
		$result = mysqli_query($con,$query);
		
		if($result && mysqli_num_rows($result) > 0)
		{
			
			$user_ID = mysqli_fetch_assoc($result);
			return $user_ID;
		}
	}
	

	//redirect to login
	header("Location: account.php");
	die;

}





?>


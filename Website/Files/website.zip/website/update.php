<?php 

    require_once("connection.php");

    if(isset($_POST['update']))
    {
        $musicI = $_GET['GetID'];
        $musicT = $_POST['title'];
        $musicA = $_POST['author'];
        $musicY = $_POST['year'];

        $query = " update music set music_title = '".$musicT."', music_author='".$musicA."',music_year='".$musicY."' where music_id='".$musicI."'";
        $result = mysqli_query($con,$query);

        if($result)
        {
            header("location:musicrated.php");
        }
        else
        {
            echo ' Please Check Your Query ';
        }
    }
    else
    {
        header("location:musicrated.php");
    }


?>


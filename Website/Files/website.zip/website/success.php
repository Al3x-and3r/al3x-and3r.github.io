<?php
    
   
    session_start();
    include("connection.php");
	include("functions.php");


    if(isset($_POST['Account_ID'])){
        $_SESSION['Account_ID']= $_POST['Account_ID'];
        echo "Welcome ".$_SESSION['Account_ID'];
    }
 
   
       
        // Transaction
        $sql = 'UPDATE products SET stock = stock - 1';
        $con-> commit();
        $result = mysqli_query($con,$sql);
    
      //Dirty Read
	//$sql = 'UPDATE products SET stock = stock-1';
    //$con -> rollback();
     //$sql = 'SELECT * from products where product_id = 1';
     //  $result = mysqli_query($con,$sql);

     // Phantom Read
     // $sql = 'UPDATE products SET stock = stock - 1';
     //$sql = 'SELECT * from products where product_id = 1';
     // $con-> commit();
     //  $sql = 'INSERT into products WHERE stock = stock + 1';
     //  $result = mysqli_query($con,$sql);
    
     // Lost Update
     // $sql ='SELECT product_id from products where product_id = 1';
     // $sql = 'UPDATE product_id from products where product_id = product_id + 1';
     // $con-> commit();
     // $sql ='SELECT product_id from products where product_id = 1';
     // $sql = 'UPDATE product_id from products where product_id = product_id + 2
     // $con -> commit();
     // $result = mysqli_query($con,sql);
   
     // Non repeatable read
     // $sql = 'UPDATE product_id from products where product_id = product_id + 1';
     // $sql = 'SELECT * from products where product_id = 2;
     // $con -> commit();
     // $sql = 'SELECT * From products where product_id = 2;
     // $con -> commit();
     // $result = mysqli_query($con,sql);
    
    $user_id = $_SESSION['Account_ID'];     
$query = "INSERT INTO subscribed_account (Account_ID, Account_Name)
VALUES ((select Account_ID from account where Account_ID = $user_id), (Select Account_Name from account where Account_ID = $user_id))"; 
$result = mysqli_query($con,$query);




?>



<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body>
     <!-- Responsive navbar-->
     <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="container">
            <a class="navbar-brand" href="#">Music Rated</a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item"><a class="nav-link active" aria-current="page" href="index.php">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" id="navbarDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">Options</a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <li><a class="dropdown-item" href="signup.php">Sign up</a></li>
                                <li><a class="dropdown-item" href="account.php">Account</a></li>
                                <li><a class="dropdown-item" href="musicrated.php">Music</a></li>
                                <li><a class="dropdown-item" href="checkout.php">Subscribe</a></li>
                                <li><hr class="dropdown-divider" /></li>
                                <li><a class="dropdown-item" href="signout.php">Sign Out</a></li>
                            </ul>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>


        <div class="jumbotron text-center">
  <h1 class="display-3">Thank You!</h1>
  <p class="lead"><strong>Please check your email</strong> Your purchase was complete!</p>
  <hr>
  <p>
    Having trouble? <a href="">Contact us</a>
  </p>
  <p class="lead">
    <a class="btn btn-primary btn-sm" href="index.php" role="button">Continue to homepage</a>
  </p>
</div>
          <!-- Bootstrap core JS-->
          <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>

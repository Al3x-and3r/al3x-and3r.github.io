<?php
error_reporting(0);
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "musicwebsite";


//HardcodedCredentials to be fixed
if(!$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname))
{

	die("failed to connect!");
}




#try {
#	$con = new PDO("mysql:host=localhost;dbname=musicwebsite",'root','');
#			$con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
#	}
#			catch(PDOException $e){
#				echo "Connection failed: ";
#				}
				#
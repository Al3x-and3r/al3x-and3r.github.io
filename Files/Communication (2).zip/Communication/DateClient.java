import java.io.*;
import java.net.Socket;
import java.util.Scanner;

class DateClient
{
    public static void main(String[] args) {

        try {
            /* make connection to server socket */
            Socket sock = new Socket("127.0.0.1",6013);
            Scanner sc = new Scanner(System.in);
          BufferedReader in =  new BufferedReader(new InputStreamReader(sock.getInputStream()));
            PrintWriter pout = new
                    PrintWriter(sock.getOutputStream(), true);

            Thread sender = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    System.out.println("You are now connected");
                    while(true){
                        message = sc.nextLine();
                        if (message.equals("/exit"))
                        {
                            try {
                                sock.close();
                            } catch (IOException e) {
                                System.out.println("Disconnecting");
                            }


                        }
                        pout.println(message);
                        pout.flush();
                    }
                }
            });
            sender.start();


            Thread receiver = new Thread(new Runnable() {
                String message;
                @Override
                public void run() {
                    try {
                        message = in.readLine();
                        while (message != null) {
                            System.out.println("Server: " + message);
                            message = in.readLine();
                        }
                        System.out.println("Unable to connect to Server");
                        pout.close();
                        sock.close();
                    } catch (IOException e) {
                        System.out.print("Client Disconnected");
                    }
                }
            });
receiver.start();
        }
        catch (IOException ioe) {
            System.err.println(ioe);
        }
    }
}



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

class DateServer
{
    public static void main(String[] args) {

        try {
            ServerSocket sock = new ServerSocket(6013);
            /* now listen for connections */

                Socket client = sock.accept();
                PrintWriter pout = new
                        PrintWriter(client.getOutputStream());
               Scanner sc = new Scanner(System.in);
                BufferedReader in;
                in = new BufferedReader(new InputStreamReader(client.getInputStream()));

                Thread sender = new Thread(new Runnable() {
                   String message;
                    @Override
                    public void run() {
                        System.out.println("You are now connected");
                        while(true){
                            message = sc.nextLine();
                            if (message.equals("/exit"))
                            {
                                try {
                                    sock.close();
                                    pout.close();
                                    client.close();

                                } catch (IOException e) {
                                    System.out.println("Disconnecting");
                                }
                            }
                            pout.println(message);
                            pout.flush();
                        }
                    }
                });
            sender.start();

                Thread recieve = new Thread(new Runnable() {
                    String message;
                    @Override
                    public void run() {
                        try {
                            message = in.readLine();
                            while (message != null){
                                System.out.println("Client: " + message);
                                message = in.readLine();
                            }
                            System.out.println("Client disconnected");
                            pout.close();
                            client.close();
                            sock.close();
                        }
                        catch (IOException e){
                           System.out.println("Server disconnected");
                        }
                    }
                });
recieve.start();
        }
        catch (IOException ioe) {
            System.err.println(ioe);
        }
    }
}